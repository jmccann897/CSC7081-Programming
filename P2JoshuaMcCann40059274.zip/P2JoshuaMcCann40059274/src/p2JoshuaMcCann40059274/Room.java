package p2JoshuaMcCann40059274;

/**
 * 
 * @author josh mccann 40059274 Room options of device objects
 *
 */
public enum Room {
	HOUSE, KITCHEN, BEDROOM, BATHROOM, LOUNGE
}
