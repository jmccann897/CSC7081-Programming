package p3;
/**
* @author - McCannJoshua 40059274
*/
public enum Type {

	HOSTEL, HOTEL, BNB;
}
