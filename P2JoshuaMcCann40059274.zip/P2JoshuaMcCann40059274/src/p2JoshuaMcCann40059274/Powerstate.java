package p2JoshuaMcCann40059274;

/**
 * @author josh mccann 40059274
 * 
 *         Powerstate of device objects
 * 
 */
public enum Powerstate {
	ON, OFF
}
